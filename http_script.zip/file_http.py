import requests
import json

sequoia_ip = '192.168.47.1'

print ("/file:")
r = requests.get('http://' + sequoia_ip + '/file')
print(json.dumps(r.json(), indent = 4))

print ("/file/internal:")
r = requests.get('http://' + sequoia_ip + '/file/internal')
print(len(r.json()))
data =json.dumps(r.json())
print(len(data))
print('------')
print(json.dumps(r.json(), indent = 4))

print ("/file/internal/0002:")
r = requests.get('http://' + sequoia_ip + '/file/internal/0002')
print(json.dumps(r.json(), indent = 4))