import requests
import shutil
import os.path

sequoia_ip = '192.168.47.1'
directories = "internal/"

r = requests.get('http://' + sequoia_ip + '/file/internal')
shot_number = len(r.json()) - 1
for i in range(1,shot_number+1):
	if i<=9:
		directory = directories + '000'+str(i)
	elif i<=99:
		directory = directories + '00'+str(i)
	elif i<=999:
		directory = directories + '0'+str(i)
	else:
		directory = directories +str(i)

	r = requests.get('http://' + sequoia_ip + '/download/' + directory, stream=True)

	if r.status_code == 200:
    	with open(os.path.basename(directory) + '.zip', 'wb') as f:
        	r.raw.decode_content = True
       		shutil.copyfileobj(r.raw, f)