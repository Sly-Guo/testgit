import requests
import json

sequoia_ip = '192.168.47.1'

r = requests.get('http://' + sequoia_ip + '/storage')

print(json.dumps(r.json(), indent = 4))