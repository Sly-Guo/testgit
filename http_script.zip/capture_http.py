import requests
import json

sequoia_ip = '192.168.47.1'

r = requests.get('http://' + sequoia_ip + '/capture')

print(json.dumps(r.json(), indent = 4))

r = requests.get('http://' + sequoia_ip + '/capture/start')
print(json.dumps(r.json(), indent = 4))

r = requests.get('http://' + sequoia_ip + '/capture/stop')

print(json.dumps(r.json(), indent = 4))
