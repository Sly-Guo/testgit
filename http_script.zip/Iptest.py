from ptpy import PTPy
from ptpy.transports.ip import IPTransport

# Default PTP/IP port assumed
c = PTPy(transport=IPTransport, device='192.168.47.1')
