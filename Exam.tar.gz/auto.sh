#!/bin/sh
file=main_test
if [ -e $file]; then
	./main_test
fi
